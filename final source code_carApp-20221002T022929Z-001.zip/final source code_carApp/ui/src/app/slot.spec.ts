import { Slot } from './slot';

describe('Slot', () => {
  it('should create an instance', () => {
    expect(new Slot()).toBeTruthy();
  });
});
