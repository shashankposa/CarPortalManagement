import { CarService } from './car-service';

describe('CarService', () => {
  it('should create an instance', () => {
    expect(new CarService()).toBeTruthy();
  });
});
