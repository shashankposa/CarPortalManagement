import { Dashboard } from './dashboard';

describe('Dashboard', () => {
  it('should create an instance', () => {
    expect(new Dashboard()).toBeTruthy();
  });
});
